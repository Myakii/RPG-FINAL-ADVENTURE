from Inventory import effect

import json 
with open (" Le chemin où y a le json ") as f :
    data = json.load(f)
get_inventory = data["objet"]
get_id = get_inventory[0]
info_Potion_de_vie = get_id

class inventory:

    def __init__(self):
        pass

    def get_name(self):
        pass

    def get_name(self):
        pass
    
    def get_name(self):
        pass
    
    def get_name(self):
        pass
    "etc"