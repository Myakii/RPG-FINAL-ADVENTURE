class effect:
    def __init__(self):
        pass

    def value(self):
        pass
    
    def type(self):
        pass
    
    def tour(self):
        pass
